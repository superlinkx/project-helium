/*
 Copyright 2011 Steven Holms <superlinkx@gmail.com>

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function lvlchecker(){switch(enemyKilled){case 0:lvl=1;break;case 100:lvl=2;break;case 200:lvl=3;break;case 300:lvl=4;break;case 400:lvl=5;break;case 500:lvl=6;break;case 600:lvl=7;break;case 700:lvl=8;break;case 800:lvl=9;break;case 900:lvl=10}switch(lvl){case 1:enemy1Speed=3;enemy2Speed=4;enemyTotal=8;sc0reMult=1;break;case 2:enemy1Speed=4;enemy2Speed=5;enemyTotal=9;sc0reMult=1;break;case 3:enemy1Speed=5;enemy2Speed=6;enemyTotal=10;sc0reMult=1;break;case 4:enemy1Speed=6;enemy2Speed=7;enemyTotal=
11;sc0reMult=1;break;case 5:enemy1Speed=7;enemy2Speed=8;enemyTotal=12;sc0reMult=1;break;case 6:enemy1Speed=8;enemy2Speed=9;enemyTotal=13;sc0reMult=1;break;case 7:enemy1Speed=9;enemy2Speed=10;enemyTotal=14;sc0reMult=1;break;case 8:enemy1Speed=10;enemy2Speed=11;enemyTotal=15;sc0reMult=1;break;case 9:enemy1Speed=11;enemy2Speed=12;enemyTotal=16;sc0reMult=1;break;case 10:enemy1Speed=12,enemy2Speed=13,enemyTotal=17,sc0reMult=1}};
