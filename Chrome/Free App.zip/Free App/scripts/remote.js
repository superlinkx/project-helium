var b = "http://superlinkx.dyndns.org/projects/hydrogen/apps/helium/"
